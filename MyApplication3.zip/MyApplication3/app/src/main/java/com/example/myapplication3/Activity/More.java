package com.example.myapplication3.Activity;

/**
 * Created by 谢朝康，陈贞校
 * 更多界面
 */

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;

import com.example.myapplication3.Adapter.NewsAdapter;
import com.example.myapplication3.JavaBean.BookNews;

import java.util.ArrayList;
import java.util.List;

public class More extends AppCompatActivity {
    private List<BookNews> bookNewses=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_more);
        /*START 各个界面间的跳转*/
        LinearLayout linearLayout=(LinearLayout) findViewById(R.id.line);
      /*  linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(More.this,BookMall.class);
                startActivity(intent);
            }
        });*/
        /*END*/
        initbooknews();
        NewsAdapter newsAdapter=new NewsAdapter(More.this,R.layout.booknews_item,bookNewses);
        ListView listView=(ListView) findViewById(R.id.more_list);
        listView.setAdapter(newsAdapter);
        /*listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent=new Intent(More.this,Introduction.class);
                startActivity(intent);
            }
        });*/
    }
    /*初始化数据：一些展示的书本信息：图片+简介*/
    private void initbooknews(){
        for (int i=0;i<1;i++){
            BookNews HZYP = new BookNews("【【武侠百万大征文】参赛作品】\n" +
                    "所谓“鸿渐于磐”源自《周易·渐卦》，原文写道：“鸿渐于磐，饮食衎衎，吉。”这句话大意是指鸿雁在高空翱翔，迁徙途中看似缓慢，可那群鸿雁循序渐进，便会寻得适合栖息的磐石，享有丰美食物。\n", "鸿渐于磐",R.drawable.hzyp);
            bookNewses.add(HZYP);
            BookNews bc=new BookNews("【特种兵第一神书】最强兵王，虎视群雄，为国而战，为民出鞘，只有站死，绝不跪生，无怨无悔！\n" +
                    "这是一本男人的书！\n" +
                    "这是一部热血的故事！","最强兵王",R.drawable.t5);
            bookNewses.add(bc);
            BookNews nc = new BookNews("命里有时终须有，命里无时要强求。\n" +
                    "这是一个长生果的故事。\n","择天记", R.drawable.ztj);
            bookNewses.add(nc);
            BookNews n = new BookNews("爷爷教了我一身算命的本事，却在我帮人算了三次命后，离开了我。从此之后，我不光给活人看命，还要给死人看，更要给……","麻衣神算子", R.drawable.myssz);
            bookNewses.add(n);
            BookNews XS = new BookNews("世上有遵循规矩的善神或者恶神，也有不守规矩的邪神。\n" +
                    "当一个穿越者和他所不认同的规矩碰撞的时候，邪神的故事就此拉开序幕……\n" +
                    "这是一个穿越成了大水母的好人，在剑与魔法的世界寻觅求索，最终改天换地的故事。","邪神", R.drawable.xs);
            bookNewses.add(XS);
            BookNews WDBZ = new BookNews("【2014星创奖第一季参赛作品】\n" +
                    "人有三魂七魄，七魄壮，能肉搏蛟龙；三魂升，可手摘日月！少年罗峰痴情三年,却换来无情背叛！夺舍融合后，他身具五魂十四魄，成为天下第一妖孽，带着霸道之势，横扫寰宇八荒！", "武道霸主",R.drawable.wdbz);
            bookNewses.add(WDBZ);
            BookNews ZZZS = new BookNews("【2014星创奖第一季参赛作品】\n" +
                    "【完本】神武大陆，强者为尊，武者天生一种武魂。\n" +
                    "五行相生相克，冰火不相容！金鳞即是池中物，冰火际会便化龙！\n" +
                    "一颗太古冰晶现世，一个烈焰圣体的天才，成就一个万界颤抖的传说！\n","至尊战神", R.drawable.zzzs);
            bookNewses.add(ZZZS);
            BookNews TC = new BookNews("【【2017历史新纪元征文】参赛作品】\n" +
                    "去他娘穿烂的盛唐、初唐，去他妈帝王将相、士大夫地主豪强富商，改良篡权的泛滥路数，我区区一个蝼蚁似得草贼就是要逆天啊；\n" +
                    "“在世曹操朱”老三算个毛，“人中之龙”李鸦儿也就那样了，杨大眼、钱婆留、还不赶快排好队。\n", "唐残",R.drawable.tc);
            bookNewses.add(TC);
        }
    }
}
