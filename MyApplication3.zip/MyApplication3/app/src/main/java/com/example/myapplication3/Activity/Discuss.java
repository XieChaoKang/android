package com.example.myapplication3.Activity;

/**
 * Created by 谢朝康，陈贞校
 * 讨论界面
 */

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import com.example.myapplication3.Adapter.dis_Adapter;
import com.example.myapplication3.JavaBean.BookNews;

import java.util.ArrayList;
import java.util.List;

public class Discuss extends AppCompatActivity {
    private List<BookNews> bookNewsList=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_discuss);
        init();
        dis_Adapter dis_adapter = new dis_Adapter(Discuss.this,R.layout.discuss_item,bookNewsList);
        ListView listView=(ListView) findViewById(R.id.dis_list);
        listView.setAdapter(dis_adapter);
    }
    private void init(){
        for(int i=0;i<1;i++){
            BookNews one=new BookNews("冒泡一下，证明我的存在，接着潜水，希望作者更新能加把劲。","墨",R.drawable.mgg);
            bookNewsList.add(one);
            BookNews w=new BookNews("作者想象力很是丰富嘛，这样让剧情出乎意料，吊足了读者胃口，作者逻辑清楚又缜密，所以不会让丰富的剧情看起来没有连接性，让读者跟着作者思维走。","陌",R.drawable.w);
            bookNewsList.add(w);
            BookNews q=new BookNews("那掌柜坐等菜肴出锅，回想适才掀开车帘看到那尸首惨状，正觉后脊发凉，忽闻厅中有人说道：“阿弥陀佛，贫僧还请施主容我师兄弟二人借宿一晚。”其音苍老深沉，一听便是老者。","沫",R.drawable.q);
            bookNewsList.add(q);
            BookNews s=new BookNews("王、常二人愈发喝得兴起，众喽啰眼见寨主痛喝三十多碗烈酒，常有酒更牛饮了六十多碗，但见那二人虽现踉跄，却依旧未分胜败，直瞧得那众喽啰欢声雷动，鼓噪连连。","老衲要还俗",R.drawable.s);
            bookNewsList.add(s);
            BookNews z=new BookNews("看书就是看作者的创意，只要有好的东西在里面，就会有自己忠实的读者！！当然只有偶们细细品位，才能看到最闪的亮点！","兔子必须死",R.drawable.z);
            bookNewsList.add(z);
            BookNews ws=new BookNews("她如此想着，随之痴望蓁蓁的倾国美貌，竟而暗生艳羡，心道：“这妮子真美，我要是能有些许及得上她，想来灵均定不舍弃我了••••••”","枫",R.drawable.ws);
            bookNewsList.add(ws);
        }
    }
}
