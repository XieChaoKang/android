package com.example.myapplication3.Activity;

/**
 * Created by 谢朝康，陈贞校
 * 我的账户界面
 */

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class My_account extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_account);
        ImageView top_image=(ImageView) findViewById(R.id.top_image);
           /*START 各个界面的相互跳转*/
        top_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(My_account.this,Personal_information.class);
                startActivity(intent);
            }
        });
           /*END 跳转*/
    }
}
