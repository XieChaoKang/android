package com.example.myapplication3.Adapter;

/**
 * Created by 谢朝康 on 2019/5/14.
 * JavaBean
 * 书城界面的适配器
 */

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.myapplication3.Activity.Introduction;
import com.example.myapplication3.JavaBean.BookNews;
import com.example.myapplication3.Activity.R;

import java.util.List;

public class NewsAdapter extends ArrayAdapter<BookNews> {
    //private int resourceid;
    public NewsAdapter(Context context, int resource, List<BookNews> objects) {
        super(context, resource, objects);
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final  BookNews bookNews=getItem(position);
        View view=LayoutInflater.from(getContext()).inflate(R.layout.booknews_item,parent,false);
        ImageView imageView=(ImageView) view.findViewById(R.id.imageview1);
        TextView textView=(TextView) view.findViewById(R.id.textview1);
        TextView textView1=(TextView) view.findViewById(R.id.textview);
        imageView.setImageResource(bookNews.getBookimage());
        textView.setText(bookNews.getBookname());
        textView1.setText(bookNews.getBookjj());
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getContext(),Introduction.class);
                intent.putExtra("bookname",bookNews.getBookname());
                intent.putExtra("bookjj",bookNews.getBookjj());
                intent.putExtra("bookimage",bookNews.getBookimage());
                getContext().startActivity(intent);
            }
        });
        return view;
    }
}
