package com.example.myapplication3.Activity;

/**
 * Created by 谢朝康，陈贞校 on 2019/5/14.
 */

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
  /*  String name=getIntent().getStringExtra("bookjj");
    int bookimageid=getIntent().getIntExtra("bookimage",0);*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        /*START 各个界面的相互跳转*/
        Button shucheng=(Button) findViewById(R.id.button_shucheng);
        Button sousuo=(Button) findViewById(R.id.sousuo);
        Button wode=(Button) findViewById(R.id.button_wode);
        RelativeLayout relativeLayout=(RelativeLayout) findViewById(R.id.rel);
        /*ImageView ztj=(ImageView) findViewById(R.id.ZTJ);*/
        TextView TL=(TextView) findViewById(R.id.taolun);
        /*跳转到书城界面*/
        shucheng.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,BookMall.class);
                startActivity(intent);
            }
        });
        relativeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,BookMall.class);
                startActivity(intent);
            }
        });
          /*跳转到搜索界面*/
        sousuo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1=new Intent(MainActivity.this,sousuo.class);
                startActivity(intent1);
            }
        });
         /*跳转到我的界面*/
        wode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,Personal_information.class);
                startActivity(intent);
            }
        });
         /*  *//*跳转到简介界面*//*
        ztj.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,Introduction.class);
                intent.putExtra("name",);
                startActivity(intent);
            }
        });*/
           /*跳转到讨论界面*/
        TL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,Discuss.class);
                startActivity(intent);
            }
        });
        /*END 界面的跳转*/
    }
}
