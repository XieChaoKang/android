package com.example.myapplication3.Activity;

/**
 * Created by 谢朝康，陈贞校
 * 意见反馈界面
 */

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class Opinion extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_opinion);
        Button button=(Button) findViewById(R.id.button);
        ImageView top_image=(ImageView) findViewById(R.id.top_image);
           /*START 各个界面的相互跳转*/
        top_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Opinion.this,Personal_information.class);
                startActivity(intent);
            }
        });
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Opinion.this,"提交成功，感谢您的建议",Toast.LENGTH_SHORT).show();//弹出TOAST，表示提交成功
                Intent intent=new Intent(Opinion.this,Personal_information.class);
                startActivity(intent);
            }
        });
           /*END 跳转*/
    }
}
