package com.example.myapplication3.Activity;

        import android.app.Activity;
        import android.app.AlertDialog;
        import android.content.DialogInterface;
        import android.content.Intent;
        import android.database.Cursor;
        import android.database.sqlite.SQLiteDatabase;
        import android.os.Bundle;
        import android.view.LayoutInflater;
        import android.view.View;
        import android.view.Window;
        import android.widget.Button;
        import android.widget.CheckBox;
        import android.widget.EditText;
        import android.widget.TextView;
        import android.widget.Toast;
        import com.example.myapplication3.Activity.myDatabaseHelper;

/**
 * 管理员登录界面
 * Created by he on 2016/9/30.
 */
public class Login_admin extends Activity {
    private EditText name;//用户名
    private EditText password;//用户密码
    private Button login;//登录按钮
    private TextView register;//注册
    private TextView forgetNum;//忘记密码
    private myDatabaseHelper dbHelper;
    private TextView mTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_login_admin);

        dbHelper = myDatabaseHelper.getInstance(this);


        name = (EditText) findViewById(R.id.account);
        password = (EditText) findViewById(R.id.password);
        login = (Button) findViewById(R.id.login);
        register = (TextView) findViewById(R.id.register);
        forgetNum = (TextView) findViewById(R.id.forgot_the_password);
        mTextView = (TextView)findViewById(R.id.top_text) ;

        //跳转到登录过的我的界面
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String nameInfo = name.getText().toString();
                String passwordInfo = password.getText().toString();
                //从数据库中获取密码并判断是否相同
              SQLiteDatabase db = dbHelper.getWritableDatabase();
                Cursor cursor = db.rawQuery("select password from admin where name=?", new String[]{nameInfo});
                String pi = null;
                if (cursor.moveToNext()) {
                    pi = cursor.getString(cursor.getColumnIndex("password"));//获取密码
                }
                //密码正确跳转到登录后的界面
                if (passwordInfo.equals(pi)) {
                    Intent intent = new Intent(Login_admin.this, Personal_information.class);
                    startActivity(intent);
                    cursor.close();
                    /*保存登录信息的帐号*/
                    String data = nameInfo;
                    Intent intent2 = new Intent(Login_admin.this, Personal_information.class);
                    intent2.putExtra("extra_data",data);
                    startActivity(intent2);
                } else {
                    Toast.makeText(Login_admin.this, "用户名或密码错误", Toast.LENGTH_SHORT).show();
                }


            }
        });
        //自定义AlertDialog用于注册
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Login_admin.this);
                LayoutInflater factory = LayoutInflater.from(Login_admin.this);
                final View textEntryView = factory.inflate(R.layout.register, null);
                builder.setTitle("用户注册");
                builder.setView(textEntryView);

                final EditText code = (EditText) textEntryView.findViewById(R.id.admin_register_info);
                final EditText name = (EditText) textEntryView.findViewById(R.id.admin_register_name);
                final EditText firstPassword = (EditText) textEntryView.findViewById(R.id.admin_register_first_password);
                final EditText secondPassword = (EditText) textEntryView.findViewById(R.id.admin_register_second_password);


                builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String codeInfo = code.getText().toString();
                        //注册码要为10086
                        if (codeInfo.equals("10086")) {
                            String nameInfo = name.getText().toString();
                            String firstPasswordInfo = firstPassword.getText().toString();
                            String secondPasswordInfo = secondPassword.getText().toString();
                            SQLiteDatabase db = dbHelper.getWritableDatabase();
                            //检测密码是否为6个数字
                            if (firstPasswordInfo.matches("[0-9]{6}")) {
                                // 两次密码是否相同
                                if (firstPasswordInfo.equals(secondPasswordInfo)) {
                                    Cursor cursor = db.rawQuery("select name from admin where name=? ", new String[]{nameInfo});
                                    //用户是否存在
                                    if (cursor.moveToNext()) {
                                        Toast.makeText(Login_admin.this, "该用户已存在", Toast.LENGTH_SHORT).show();
                                    } else {
                                        db.execSQL("insert into admin(name,password)values(?,?)", new String[]{nameInfo, firstPasswordInfo});
                                    }
                                } else {
                                    Toast.makeText(Login_admin.this, "两次密码不相同", Toast.LENGTH_SHORT).show();
                                }
                            } else {
                                Toast.makeText(Login_admin.this, "密码为6位纯数字", Toast.LENGTH_SHORT).show();
                            }


                        } else {
                            Toast.makeText(Login_admin.this, "注册码错误", Toast.LENGTH_SHORT).show();
                        }
                    }
                });


                builder.create().show();

            }
        });

        forgetNum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Login_admin.this, "此功能暂不支持", Toast.LENGTH_SHORT).show();
            }
        });

    }
}
