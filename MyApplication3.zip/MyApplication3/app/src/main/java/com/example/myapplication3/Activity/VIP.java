package com.example.myapplication3.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class VIP extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vip);
        ImageView imageView=(ImageView) findViewById(R.id.line_image);
           /*START 点击支付按钮后的处理*/
        Button pay=(Button) findViewById(R.id.pay);
        pay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(VIP.this,Personal_information.class);
                startActivity(intent);
                Toast.makeText(VIP.this,"支付成功，恭喜您成为VIP",Toast.LENGTH_SHORT).show();
            }
        });
           /*END */
           /*跳到我的界面*/
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(VIP.this,Personal_information.class);
                startActivity(intent);
            }
        });
    }
}
