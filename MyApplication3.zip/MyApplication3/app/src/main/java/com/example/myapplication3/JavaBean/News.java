package com.example.myapplication3.JavaBean;
/*
* Created by 谢朝康，陈贞校 on 2019/5/18.
 * 小说实体类*/

public class News {

    private String title;

    private String content;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

}