package com.example.myapplication3.Adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.myapplication3.JavaBean.BookNews;
import com.example.myapplication3.Activity.R;

import java.util.List;

/**
 * Created by 谢朝康,陈贞校 on 2019/5/18.
 * introduction 活动的适配器
 */

public class in_Adapter extends ArrayAdapter<BookNews>{
    private int resourceid;
    public in_Adapter(Context context, int resource, List<BookNews> objects) {
        super(context, resource, objects);
        resourceid=resource;
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        BookNews bookNews=getItem(position);
        View view= LayoutInflater.from(getContext()).inflate(resourceid,parent,false);
        ImageView imageView=(ImageView) view.findViewById(R.id.in_image);
        TextView textView1=(TextView) view.findViewById(R.id.name);
        TextView textView=(TextView) view.findViewById(R.id.in_text);
        imageView.setImageResource(bookNews.getBookimage());
        textView.setText(bookNews.getBookname());
        textView1.setText(bookNews.getBookjj());
        return view;
    }
}
