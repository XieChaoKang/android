package com.example.myapplication3.JavaBean;

/**
 * Created by 谢朝康，陈贞校 on 2019/5/14.
 * JavaBean
 * 书的信息：图片+简介
 */

public class BookNews {
    private String bookname;//书名
    private int bookimage;//书的图片
    private String bookjj;//书的简介
    public BookNews(String bookname,String bookjj, int bookimage){
        this.bookjj=bookjj;
        this.bookimage=bookimage;
        this.bookname=bookname;
    }

    public String getBookname() {
        return bookname;
    }

    public String getBookjj() {
        return bookjj;
    }

    public int getBookimage() {
        return bookimage;
    }
}
